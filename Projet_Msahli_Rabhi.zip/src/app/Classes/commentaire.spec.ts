import { Commentaire } from './commentaire';

describe('Commentaire', () => {
  it('should create an instance', () => {
    expect(new Commentaire()).toBeTruthy();
  });
});
