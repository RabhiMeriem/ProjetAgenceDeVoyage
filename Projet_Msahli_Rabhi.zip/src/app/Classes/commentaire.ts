export class Commentaire {
    constructor(){}
}
