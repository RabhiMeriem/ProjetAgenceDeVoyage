import { Voyage } from './voyage';

describe('Voyage', () => {
  it('should create an instance', () => {
    expect(new Voyage()).toBeTruthy();
  });
});
