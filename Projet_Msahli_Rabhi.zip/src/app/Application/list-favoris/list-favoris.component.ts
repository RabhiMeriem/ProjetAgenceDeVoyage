import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-favoris',
  templateUrl: './list-favoris.component.html',
  styleUrls: ['./list-favoris.component.css']
})
export class ListFavorisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
